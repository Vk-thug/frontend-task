// USER DETAILS PAGE TABLE HEADER MENU
const ldtheader = [
    {
        title: 'Avatar',
        styles: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900 capitalise',
    },
    {
        title: 'Unique ID',
        styles: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900 capitalise',
    },
    {
        title: 'Name',
        styles: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900 capitalise',
    },
    {
        title: 'Email',
        styles: 'px-6 py-4 whitespace-nowrap text-sm text-gray-900 capitalise',
    },
];


export {
    ldtheader,
}