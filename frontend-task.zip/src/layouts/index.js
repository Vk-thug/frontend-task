
import WebLayout from "./WebLayout/WebLayout";

export {
    WebLayout,
};