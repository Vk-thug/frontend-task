import DetailsPage from './DetailsPage/DetailsPage';
import AddUser from './AddUser/AddUser';


export {
  DetailsPage,
  AddUser,
};